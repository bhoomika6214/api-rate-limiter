const memoryStore = require("../store/memoryStore");

function rateLimiter(options) {
  const {
    limit = 5,
    windowMs = 60 * 1000
  } = options;

  return (req, res, next) => {
    const ip = req.ip;
    const currentTime = Date.now();

    const data = memoryStore.get(ip);

    if (!data) {
      memoryStore.set(ip, {
        count: 1,
        startTime: currentTime
      });
      return next();
    }

    if (currentTime - data.startTime > windowMs) {
      memoryStore.set(ip, {
        count: 1,
        startTime: currentTime
      });
      return next();
    }

    if (data.count >= limit) {
      return res.status(429).json({
        message: "Too many requests. Please try again later."
      });
    }

    data.count += 1;
    memoryStore.set(ip, data);
    next();
  };
}

module.exports = rateLimiter;
