# API Rate Limiting Middleware

## Features
- IP-based rate limiting
- Configurable per route
- Returns HTTP 429 on limit exceed
- In-memory or MongoDB support

## Usage

```js
rateLimiter({
  limit: 5,
  windowMs: 60000
})
