const express = require("express");
const rateLimiter = require("../middleware/rateLimiter");

const router = express.Router();

router.get(
  "/limited",
  rateLimiter({ limit: 3, windowMs: 60000 }),
  (req, res) => {
    res.json({ message: "This route is rate limited" });
  }
);

router.get("/open", (req, res) => {
  res.json({ message: "This route is open" });
});

module.exports = router;
